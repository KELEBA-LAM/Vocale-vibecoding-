const messages = {
    auth: {
        sessionExpired: 'Sesi anda telah tamat. Sila log masuk semula untuk meneruskan.'
    },
    nav: {
        loggedInAs: 'Log masuk sebagai',
        logOut: 'Log keluar',
        contentManagement: 'Content Management'
    },
    home: {
        title: 'OWASP Threat Dragon',
        imgAlt: 'Logo Threat Dragon',
        description: 'OWASP Threat Dragon adalah aplikasi percuma, sumber terbuka, lintas platform untuk mencipta model ancaman. Gunakannya untuk melukis gambarajah pemodelan ancaman dan mengenal pasti ancaman bagi sistem anda. Dengan penekanan pada kelenturan dan kesederhanaan, ia mudah diakses untuk semua jenis pengguna.'
    },
    providers: {
        desktop: {
            displayName: 'Threat Dragon',
            loginWith: 'Mula'
        },
        github: {
            displayName: 'GitHub',
            loginWith: 'Log masuk dengan'
        },
        gitlab: {
            displayName: 'GitLab',
            loginWith: 'Log masuk dengan'
        },
        bitbucket: {
            displayName: 'Bitbucket',
            loginWith: 'Log masuk dengan'
        },
        google: {
            displayName: 'Google',
            loginWith: 'Log masuk dengan'
        },
        local: {
            displayName: 'Sesi Tempatan',
            loginWith: 'Log masuk ke'
        }
    },
    dashboard: {
        welcome: {
            title: 'Selamat Datang!',
            description: 'Anda bersedia untuk memulakan membuat rekabentuk aplikasi anda lebih selamat. Anda boleh membuka model ancaman sedia ada atau membuat yang baru dengan memilih salah satu pilihan di bawah. '
        },
        actions: {
            openExisting: 'Buka model ancaman sedia ada',
            createNew: 'Cipta model ancaman baru yang kosong',
            readDemo: 'Teroka model ancaman contoh',
            importExisting: 'Import model ancaman melalui JSON',
            createFromTemplate: 'Create model from a Template'
        }
    },
    demo: {
        select: 'Pilih model ancaman demo dari senarai di bawah'
    },
    desktop: {
        file: {
            heading: 'Fail',
            clearRecentDocs: 'Padam Menu',
            close: 'Tutup Model',
            closeWindow: 'Tutup Tetingkap',
            new: 'Model Baharu',
            open: 'Buka Model',
            recentDocs: 'Buka Terkini',
            save: 'Simpan Model',
            saveAs: 'Simpan Model Sebagai'
        },
        help: {
            heading: 'Bantuan',
            docs: 'Dokumentasi',
            visit: 'Lawati kami di OWASP',
            sheets: 'Lembaran Panduan OWASP',
            github: 'Lawati kami di GitHub',
            submit: 'Hantar Isu',
            check: 'Semak kemas kini ...',
            about: {
                about: 'About',
                version: 'Version'
            }
        }
    },
    repository: {
        select: 'Pilih',
        from: 'repositori dari senarai di bawah',
        noneFound: 'Tiada repositori dijumpai. Untuk memulakan, cipta repositori baru di'
    },
    branch: {
        select: 'Pilih cawangan dari',
        from: 'dari senarai di bawah atau',
        chooseRepo: 'pilih repo lain',
        or: 'atau',
        addNew: 'tambah cawangan baru',
        protectedBranch: 'Cawangan Dilindungi',
        nameRequired: 'Nama cawangan diperlukan',
        nameExists: 'Nama cawangan sudah wujud',
        refBranch: 'Cawangan Rujukan',
        add: 'tambah cawangan',
        cancel: 'Batal',
        name: 'nama cawangan',
    },
    folder: {
        select: 'Select a',
        from: 'folder from the list below',
        noneFound: 'This folder is empty, You can create a new threat model here.'
    },
    threatmodelSelect: {
        select: 'Pilih Model Ancaman dari',
        from: 'dari senarai di bawah, atau pilih yang lain',
        branch: 'cawangan',
        or: 'atau',
        repo: 'repo',
        newThreatModel: 'Cipta Model Ancaman Baharu'
    },
    template:{
        startFromLocalTemplate: 'Start from a Local Template',
        select: 'Select a Template from the list below',
        selectDescription: 'Templates provide a starting point for new threat models, pre-populated with relevant components and threats.',
        noTemplates: 'No templates found',
        templatesLocalSession: 'Remote templates are not available for local sessions.',
        search: 'Search templates...',
        exportTemplate: 'Export as Template',
        tags: 'Tags',
        name: 'Template Name',
        description: 'Template Description',
        saveTemplate: 'Save Template',
        addNew: 'Add New Template',
        manage: 'Manage Templates',
        manageDescription: 'Import, export, and manage your threat model templates here.',
        editTemplate: 'Edit Template',
        addTagsPlaceholder: 'Add tags...',
        updateSuccess: 'Template updated successfully',
        importSuccess: 'Template imported successfully',
        deleteSuccess: 'Template deleted successfully',
        deleteTitle: 'Confirm Delete',
        deleteConfirm: 'Are you sure you want to delete "{name}"?',
        errors: {
            invalidJson: 'Invalid JSON. Please check your template file and try again',
            invalidTemplate: 'Invalid template format. Please check your template file and try again',
            loadFailed: 'Failed to load templates. Please try again',
            duplicateTemplate: 'A template with this name already exists. Please use a different name',
            updateFailed: 'Failed to update template',
            deleteFailed: 'Failed to delete template'
        },
        warnings: {
            templateSave: 'Could not save the template. Check the developer console for more information',
            invalidSchema: 'Template does not strictly match schema. Details in the developer console'
        },
        prompts: {
            templateSaved: 'Template successfully saved',
            templateDownloading: 'Downloading template'
        },
        repo: {
            notInitialized: {
                title: 'Template Repository Not Initialized',
                userMessage: 'The template repository has not been initialized. Please contact your administrator.',
                adminMessage: 'Please go to the Manage Templates page to initialize the template repository.'
            },
            notConfigured: {
                title: 'Template Repository Not Configured',
                userMessage: 'The template repository is not configured. Please set up the repository to access templates.'
            },
            notFound: {
                title: 'Template Repository Not Found',
                userMessage: 'The repository {repoName} is not a valid repository. Please check your configuration.'
            },
            bootstrap:{
                bootstrapping:'Initializing..',
                title: 'Initialize Template Repository',
                description: 'This will create the necessary folder structure within the repository if it does not already exist.',
                action: 'Initialize',
                success: 'Template repository successfully initialized.',
                error: 'Could not initialize the template repository. Check the developer console for more information.'
            }
        },
    },
    threatmodel: {
        contributors: 'Penyumbang',
        contributorsPlaceholder: 'Mulakan menaip untuk menambah penyumbang',
        description: 'Penerangan sistem peringkat tinggi',
        dragAndDrop: 'Seret dan lepaskan atau ',
        editing: 'Penyuntingan',
        jsonPaste: 'Letakkan fail JSON model ancaman di sini atau tampal kandungannya:',
        owner: 'Pemilik',
        reviewer: 'Pemeriksa',
        title: 'Tajuk',
        diagram: {
            diagrams: 'Gambarajah',
            addNewDiagram: 'Tambah gambarajah baru...',
            generic: {
                defaultTitle: 'Gambarajah generik baru',
                defaultDescription: 'Penerangan gambarajah generik baru',
                select: 'Generik'
            },
            stride: {
                defaultTitle: 'Gambarajah STRIDE baru',
                defaultDescription: 'Penerangan gambarajah STRIDE baru',
                select: 'STRIDE'
            },
            linddun: {
                defaultTitle: 'Gambarajah LINDDUN baru',
                defaultDescription: 'Penerangan gambarajah LINDDUN baru',
                select: 'LINDDUN'
            },
            plot4ai: {
                defaultTitle: 'Gambarajah PLOT4ai baru',
                defaultDescription: 'Penerangan gambarajah PLOT4ai baru',
                select: 'PLOT4ai'
            },
            die: {
                defaultTitle: 'Gambarajah CIA-DIE baru',
                defaultDescription: 'Penerangan gambarajah CIA-DIE baru',
                select: 'CIADIE'
            },
            cia: {
                defaultTitle: 'Gambarajah CIA baru',
                defaultDescription: 'Penerangan gambarajah CIA baru',
                select: 'CIA'
            },
            eop: {
                defaultTitle: 'Gambarajah EoP permainan baru',
                defaultDescription: 'Penerangan gambarajah EoP permainan baru',
                select: 'EoP permainan'
            }
        },
        threats: 'Ancaman',
        errors: {
            create: 'Could not create the threat model file.  Check the developer console for more information',
            dropSingleFileOnly: 'Seret dan lepaskan memerlukan satu fail sahaja.',
            invalidJson: 'JSON tidak sah. Sila periksa model anda dan cuba lagi',
            invalidModel: 'The threat model file does not validate correctly. Please check your model and try again',
            onlyJsonAllowed: 'Hanya fail yang berakhir dengan .json yang disokong.',
            open: 'Ralat membuka Model Ancaman ini. Semak konsol pembangun untuk maklumat lanjut',
            save: 'Ralat menyimpan Model Ancaman ini. Semak konsol pembangun untuk maklumat lanjut',
            createConflict: 'A threat model with this name already exists. Please use a different name.'
        },
        warnings: {
            export: 'Could not export the Threat Model. Check the developer console for more information',
            jsonSchema: 'Model does not strictly match schema. Details from the developer console',
            noModelOpen: 'No model open',
            otmUnsupported: 'Import of Open Threat Model file format not yet supported',
            save: 'Could not save the Threat Model. Check the developer console for more information',
            tmUnsupported: 'Import of TM-BOM files converts the file format to Threat Dragon',
            v1Translate: 'Model versi 1.x yang diimport akan dinaik tarafkan ke skema versi 2.0'
        },
        prompts: {
            created: 'Threat model successfully created',
            exported: 'Threat model exported',
            opened: 'Model ancaman berjaya dibuka',
            downloading: 'Downloading threat model',
            saved: 'Model ancaman berjaya disimpan'
        },
        properties: {
            title: 'Ciri-ciri',
            emptyState: 'Pilih elemen pada graf untuk disunting',
            name: 'Nama',
            text: 'Teks',
            description: 'Penerangan',
            outOfScope: 'Di luar Skop',
            bidirection: 'Dwi-Arah',
            reasonOutOfScope: 'Sebab di luar skop',
            handlesCardPayment: 'Bayaran Kad',
            handlesGoodsOrServices: 'Barang atau Perkhidmatan',
            isALog: 'Adalah Log',
            isEncrypted: 'Dienkripsi',
            isSigned: 'Ditandatangani',
            isWebApplication: 'Aplikasi Web',
            privilegeLevel: 'Tahap Keistimewaan',
            providesAuthentication: 'Menyediakan Pengesahan',
            protocol: 'Protokol',
            publicNetwork: 'Rangkaian Awam',
            storesCredentials: 'Simpan Kredensial',
            storesInventory: 'Simpan Inventori'
        },
        buttons: {
            delete: 'Padam yang dipilih',
            redo: 'Buat semula suntingan',
            shortcuts: 'Pintasan papan kekunci',
            toggleGrid: 'Togel grid',
            undo: 'Buat asal semula suntingan',
            zoomIn: 'Zum masuk',
            zoomOut: 'Zum keluar'
        },
        shortcuts: {
            title: 'Pintasan',
            copy: {
                shortcut: '(ctrl/cmd) + c',
                action: 'Salin'
            },
            paste: {
                shortcut: '(ctrl/cmd) + v',
                action: 'Tampal'
            },
            undo: {
                shortcut: '(ctrl/cmd) + z',
                action: 'Buat asal semula'
            },
            redo: {
                shortcut: '(ctrl/cmd) + y',
                action: 'Buat semula'
            },
            delete: {
                shortcut: 'padam',
                action: 'Padam'
            },
            pan: {
                shortcut: 'shift + klik kiri (tahan/tarik)',
                action: 'Pan'
            },
            multiSelect: {
                shortcut: 'klik kiri pada ruang kosong dan tarik',
                action: 'Pilih pelbagai'
            },
            zoom: {
                shortcut: '(ctrl/cmd) + roda tetikus',
                action: 'Zum'
            },
            save: {
                shortcut: '(ctrl/cmd) + s',
                action: 'Save'
            }
        },
        stencil: {
            boundaries: 'Sempadan',
            components: 'Komponen',
            entities: 'Entiti',
            metadata: 'Metadata',
            search: 'Carian',
            notFound: 'Kami belum memilikinya, ingin membuka isu? :)'
        },
        shapes: {
            actor: 'Pelakon',
            flow: 'Aliran Data',
            flowStencil: 'Aliran Data',
            process: 'Proses',
            store: 'Simpan',
            text: 'Teks Penerangan',
            trustBoundary: 'Sempadan Kepercayaan'
        }
    },
    forms: {
        apply: 'Menerapkan',
        cancel: 'Batal',
        close: 'Tutup',
        closeModel: 'Tutup Model',
        delete: 'Padam',
        discardTitle: 'Buang Perubahan?',
        discardMessage: 'Adakah anda pasti mahu membuang perubahan anda?',
        duplicate: 'Menduplikasi',
        edit: 'Edit',
        export: 'Mengekspor',
        exportAs: 'Eksport Model Sebagai',
        exportHtml: 'Laporan HTML',
        exportPdf: 'Laporan PDF',
        exportTd: 'Asal (Threat Dragon)',
        exportTemplate: 'As Template',
        exportTmBom: 'As TM-BOM',
        exportOtm: 'Ancaman Terbuka Model (OTM)',
        import: 'Import',
        ok: 'OK',
        open: 'Buka',
        openModel: 'Buka Model',
        print: 'Cetak',
        reload: 'Muat Semula',
        remove: 'Alih Keluar',
        report: 'Laporan',
        save: 'Simpan',
        saveAs: 'Simpan Sebagai',
        saveModel: 'Simpan Model',
        saveModelAs: 'Simpan Model Sebagai',
        search: 'Carian',
        next: 'seterusnya',
        previous: 'sebelumnya'
    },
    cards: {
        details: 'Butiran kad',
        noDetails: 'tiada butiran tersedia',
        unknown: 'Tidak diketahui',
        properties: {
            suit: 'Kategori',
            number: 'Nombor'
        },
    },
    threats: {
        model: {
            cia: {
                header: '--- CIA ---',
                confidentiality: 'Kerahsiaan',
                integrity: 'Integriti',
                availability: 'Ketersediaan'
            },
            ciadie: {
                header: '--- CIA-DIE ---',
                confidentiality: 'Kerahsiaan',
                integrity: 'Integriti',
                availability: 'Ketersediaan',
                distributed: 'Teragih',
                immutable: 'Tidak Berubah',
                ephemeral: 'Efemeral'
            },
            linddun: {
                header: '--- LINDDUN ---',
                linkability: 'Pautan',
                identifiability: 'Pengenalpastian',
                nonRepudiation: 'Tidak boleh menafikan',
                detectability: 'Ketahuan',
                disclosureOfInformation: 'Pendedahan maklumat',
                unawareness: 'Tanpa sedar',
                nonCompliance: 'Tidak Mematuhi'
            },
            plot4ai: {
                header: '--- PLOT4ai ---',
                techniqueProcesses: 'Teknik & Proses',
                accessibility: 'Aksesibiliti',
                identifiabilityLinkability: 'Pengenalpastian & Pautan',
                security: 'Keselamatan',
                safety: 'Keselamatan',
                unawareness: 'Tanpa sedar',
                ethicsHumanRights: 'Etika & Hak Asasi Manusia',
                nonCompliance: 'Tidak Mematuhi'
            },
            stride: {
                header: '--- STRIDE ---',
                spoofing: 'Penipuan',
                tampering: 'Penyelewengan',
                repudiation: 'Penafian',
                informationDisclosure: 'Pendedahan maklumat',
                denialOfService: 'Penafian Perkhidmatan',
                elevationOfPrivilege: 'Kenaikan Hak'
            },
            eop: {
                header: '--- EoP ---',
                dataValidationAndEncoding: 'Data Validation & Encoding',
                authentication: 'Authentication',
                sessionManagement: 'Session Management',
                authorization: 'Authorization',
                cryptography: 'Cryptography',
                cornucopia: 'Cornucopia',
                wildCard: 'Wild Card'
            }
        },
        generic: {
            default: 'Ancaman generik baru',
            cia: 'Ancaman CIA baru',
            ciadie: 'Ancaman CIA-DIE baru',
            linddun: 'Ancaman LINDDUN baru',
            plot4ai: 'Ancaman PLOT4ai baru',
            stride: 'Ancaman STRIDE baru',
            eop: 'Ancaman EoP permainan baru'
        },
        edit: 'Sunting Ancaman',
        confirmDeleteTitle: 'Sahkan Padam',
        confirmDeleteMessage: 'Adakah anda benar-benar ingin memadam ancaman ini?',
        description: 'Berikan penerangan bagi ancaman ini',
        emptyThreat: 'Pilih elemen pada graf untuk menambah ancaman',
        mitigation: 'Berikan pemulihan untuk ancaman ini atau sebab jika status adalah T/A',
        newThreat: 'Ancaman Baru',
        newThreatByType: 'Ancaman Baru mengikut Jenis',
        newThreatByContext: 'Ancaman Baru mengikut Konteks',
        properties: {
            description: 'Penerangan',
            mitigation: 'Pemulihan',
            modelType: 'Jenis Model',
            number: 'Nombor',
            severity: 'Keutamaan',
            score: 'Skor',
            status: 'Status',
            title: 'Tajuk',
            type: 'Jenis'
        },
        status: {
            notApplicable: 'T/A',
            open: 'Buka',
            mitigated: 'Ditangani'
        },
        severity: {
            tbd: 'TBD',
            low: 'Rendah',
            medium: 'Sederhana',
            high: 'Tinggi',
            critical: 'kritikal'
        },
        validation: {
            error: 'Nombor kad diperlukan.',
            cardNumberRequired: 'Anda mesti memilih nombor kad sebelum menyimpan.'
        }
    },
    report: {
        options: {
            showOutOfScope: 'Tunjukkan elemen di luar skop',
            showMitigatedThreats: 'Tunjukkan ancaman yang ditangani',
            showModelDiagrams: 'Tunjukkan gambarajah model',
            showEmpty: 'Tunjukkan elemen kosong',
            showProperties: 'Show element properties',
            showBranding: 'Logo Threat Dragon'
        },
        title: 'Laporan model ancaman untuk',
        dateGenerated: 'Tarikh Dijana',
        executiveSummary: 'Ringkasan Eksekutif',
        notProvided: 'Tidak disediakan',
        summary: 'Ringkasan',
        threatStats: {
            total: 'Jumlah Ancaman',
            mitigated: 'Jumlah Ditangani',
            notApplicable: 'Total Not Applicable',
            notMitigated: 'Belum Ditangani',
            openCritical: 'Buka / Keutamaan Kritikal',
            openHigh: 'Buka / Keutamaan Tinggi',
            openMedium: 'Buka / Keutamaan Sederhana',
            openLow: 'Buka / Keutamaan Rendah',
            openTbd: 'Buka / Keutamaan TBD',
            openUnknown: 'Buka / Keutamaan Tidak Diketahui'
        }
    },
    upgrade: {
        modal: {
            header: 'Kemas kini Model Ancaman',
            welcome: 'Selamat datang ke versi 2 OWASP Threat Dragon!',
            p1: 'Versi 2 menggunakan pustaka lukisan yang berbeza, yang akan mengubah cara sebahagian daripada model ancaman anda disimpan. Walaupun kebanyakan gambarajah akan kelihatan sama seperti versi sebelumnya Threat Dragon, terdapat kes di mana mereka mungkin perlu diselaraskan sedikit.',
            p2: 'Selepas menutup modal ini, anda akan melihat bagaimana setiap gambarajah dalam model ini dipaparkan dalam format versi 2. Sila buat nota gambarajah mana yang perlu anda selaraskan. Ini adalah peningkatan satu kali, dan anda tidak seharusnya melihat mesej ini lagi selepas menyimpan model ini.'
        },
        instructions: 'Hebat! Mari bawa anda ke model anda.',
        continue: 'Teruskan ke Model Ancaman'
    }
};

export default messages;
