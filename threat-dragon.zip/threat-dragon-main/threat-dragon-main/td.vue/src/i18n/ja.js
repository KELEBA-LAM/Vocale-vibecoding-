const messages = {
    auth: {
        sessionExpired: 'セッションの有効期限が切れました。再ログインしてください。'
    },
    nav: {
        loggedInAs: 'ユーザー名',
        logOut: 'ログアウト',
        contentManagement: 'Content Management'
    },
    home: {
        title: 'OWASP Threat Dragon',
        imgAlt: 'Threat Dragonロゴ',
        description: 'OWASP Threat Dragonは無償で、脅威モデリングのソフトです。オープンソースで複数のプラットホームに対応しています。Threat Dragonで脅威モデルを作成することによって、システムに対する脅威が明確になります。重視が多様性と使い勝手に置かれているので、簡単に利用できます。'
    },
    providers: {
        desktop: {
            displayName: '開始',
            loginWith: 'Threat Dragon'
        },
        github: {
            displayName: 'GitHubで',
            loginWith: 'ログイン'
        },
        gitlab: {
            displayName: 'GitLab',
            loginWith: 'Login with'
        },
        bitbucket: {
            displayName: 'Bitbucketで',
            loginWith: 'ログイン'
        },
        google: {
            displayName: 'Google',
            loginWith: 'ログイン'
        },
        local: {
            displayName: 'ローカルセッション',
            loginWith: 'ログイン'
        }
    },
    dashboard: {
        welcome: {
            title: 'ようこそ！',
            description: 'システムの設計をもっとセキュアにしましょう。既存の脅威モデルを開くか、次の選択肢から一つを選んで新しい脅威モデルを作成できます。'
        },
        actions: {
            openExisting: '既存の脅威モデルを開く',
            createNew: '新しい脅威モデルを作る',
            readDemo: '脅威モデルの一例を見る',
            importExisting: '脅威モデルをJSONからインポートする',
            createFromTemplate: 'Create model from a Template'
        }
    },
    demo: {
        select: '次のものから脅威モデルの一例を選んでください'
    },
    desktop: {
        file: {
            heading: 'ファイル',
            clearRecentDocs: 'メニューを空にする',
            close: 'モデルを閉じる',
            closeWindow: 'ウインドウを閉じる',
            new: '新しいモデルを作る',
            open: 'モデルを開く',
            recentDocs: '最近開いたモデル',
            save: 'モデルを保存',
            saveAs: '名前を付けてモデルを保存'
        },
        help: {
            heading: 'ヘルプ',
            docs: 'ドキュメンテーション',
            visit: 'OWASPでのページ',
            sheets: 'OWASP Cheat Sheets',
            github: 'GitHubリポジトリ',
            submit: '問題を報告',
            check: '更新を確認...',
            about: {
                about: 'About',
                version: 'Version'
            }
        }
    },
    repository: {
        select: '次のものから',
        from: 'リポジトリを選択してください',
        noneFound: 'リポジトリが見付かりません。新しいリポジトリを作成してください。'
    },
    branch: {
        select: '次のものから',
        from: 'ブランチ名を選択してください',
        chooseRepo: 'リポジトリの切り替え',
        or: 'または',
        addNew: '新しいブランチを追加します。',
        protectedBranch: '保護されたブランチ',
        nameRequired: 'ブランチ名が必要です。',
        nameExists: 'ブランチ名が既に存在します。',
        refBranch: 'リファレンスブランチ',
        add: 'ブランチを追加する\n',
        cancel: '取り消し',
        name: 'ブランチ名',
    },
    folder: {
        select: 'Select a',
        from: 'folder from the list below',
        noneFound: 'This folder is empty, You can create a new threat model here.'
    },
    threatmodelSelect: {
        select: '次のものから',
        from: '脅威モデルを選ぶか',
        branch: '別のブランチ',
        or: 'または',
        repo: 'リポジトリに切り替える',
        newThreatModel: '新しい脅威モデルを作成する'
    },
    template:{
        startFromLocalTemplate: 'Start from a Local Template',
        select: 'Select a Template from the list below',
        selectDescription: 'Templates provide a starting point for new threat models, pre-populated with relevant components and threats.',
        noTemplates: 'No templates found',
        templatesLocalSession: 'Remote templates are not available for local sessions.',
        search: 'Search templates...',
        exportTemplate: 'Export as Template',
        tags: 'Tags',
        name: 'Template Name',
        description: 'Template Description',
        saveTemplate: 'Save Template',
        addNew: 'Add New Template',
        manage: 'Manage Templates',
        manageDescription: 'Import, export, and manage your threat model templates here.',
        editTemplate: 'Edit Template',
        addTagsPlaceholder: 'Add tags...',
        updateSuccess: 'Template updated successfully',
        importSuccess: 'Template imported successfully',
        deleteSuccess: 'Template deleted successfully',
        deleteTitle: 'Confirm Delete',
        deleteConfirm: 'Are you sure you want to delete "{name}"?',
        errors: {
            invalidJson: 'Invalid JSON. Please check your template file and try again',
            invalidTemplate: 'Invalid template format. Please check your template file and try again',
            loadFailed: 'Failed to load templates. Please try again',
            duplicateTemplate: 'A template with this name already exists. Please use a different name',
            updateFailed: 'Failed to update template',
            deleteFailed: 'Failed to delete template'
        },
        warnings: {
            templateSave: 'Could not save the template. Check the developer console for more information',
            invalidSchema: 'Template does not strictly match schema. Details in the developer console'
        },
        prompts: {
            templateSaved: 'Template successfully saved',
            templateDownloading: 'Downloading template'
        },
        repo: {
            notInitialized: {
                title: 'Template Repository Not Initialized',
                userMessage: 'The template repository has not been initialized. Please contact your administrator.',
                adminMessage: 'Please go to the Manage Templates page to initialize the template repository.'
            },
            notConfigured: {
                title: 'Template Repository Not Configured',
                userMessage: 'The template repository is not configured. Please set up the repository to access templates.'
            },
            notFound: {
                title: 'Template Repository Not Found',
                userMessage: 'The repository {repoName} is not a valid repository. Please check your configuration.'
            },
            bootstrap:{
                bootstrapping:'Initializing..',
                title: 'Initialize Template Repository',
                description: 'This will create the necessary folder structure within the repository if it does not already exist.',
                action: 'Initialize',
                success: 'Template repository successfully initialized.',
                error: 'Could not initialize the template repository. Check the developer console for more information.'
            }
        },
    },
    threatmodel: {
        contributors: '貢献者',
        contributorsPlaceholder: '貢献した方の名前',
        description: 'システム概要',
        dragAndDrop: 'ドラッグ・アンド・ドロップで脅威モデルを指定するか、',
        editing: '編集',
        jsonPaste: 'JSONファイルの内容をここに貼り付けてください',
        owner: 'オーナー',
        reviewer: '検証者',
        title: 'タイトル',
        diagram: {
            diagrams: '図面',
            addNewDiagram: '新しい図面を追加...',
            generic: {
                defaultTitle: '一般の図面',
                defaultDescription: '図面の概要',
                select: '一般'
            },
            stride: {
                defaultTitle: 'STRIDE図',
                defaultDescription: '新しいSTRIDE図の概要',
                select: 'STRIDE'
            },
            linddun: {
                defaultTitle: 'LINDDUN図',
                defaultDescription: '新しいLINDDUN図の概要',
                select: 'LINDDUN'
            },
            plot4ai: {
                defaultTitle: 'PLOT4ai図',
                defaultDescription: '新しいPLOT4ai図の概要',
                select: 'PLOT4ai'
            },
            die: {
                defaultTitle: 'CIA-DIE図',
                defaultDescription: '新しいCIA-DIE図の概要',
                select: 'CIADIE'
            },
            cia: {
                defaultTitle: 'CIA図',
                defaultDescription: '新しいCIA図の概要',
                select: 'CIA'
            },
            eop: {
                defaultTitle: 'EoP ゲーム 図',
                defaultDescription: '新しいEoP ゲーム 図の概要',
                select: 'EoP ゲーム'
            }
        },
        threats: '脅威',
        errors: {
            create: 'Could not create the threat model file.  Check the developer console for more information',
            dropSingleFileOnly: '単一のファイルをドロップしてください。',
            invalidJson: 'ファイルのJSONフォーマットに対応していません。モデルを確認したうえ、もう一度試してみてください',
            invalidModel: 'The threat model file does not validate correctly. Please check your model and try again',
            onlyJsonAllowed: '拡張子.jsonのファイルのみに対応しています。',
            open: '脅威モデルを開く時にエラーが発生しました。開発者コンソールを確認してください。',
            save: '脅威モデルを保存時にエラーが発生しました。開発者コンソールを確認してください。',
            createConflict: 'A threat model with this name already exists. Please use a different name.'
        },
        warnings: {
            export: 'Could not export the Threat Model. Check the developer console for more information',
            jsonSchema: 'Model does not strictly match schema. Details from the developer console',
            noModelOpen: 'No model open',
            otmUnsupported: 'Import of Open Threat Model file format not yet supported',
            save: 'Could not save the Threat Model. Check the developer console for more information',
            tmUnsupported: 'Import of TM-BOM files converts the file format to Threat Dragon',
            v1Translate: 'バージョン1.xのモデルは、インポート時にバージョン2.0のフォーマットに変換されます。'
        },
        prompts: {
            created: 'Threat model successfully created',
            exported: 'Threat model exported',
            opened: '脅威モデルを読み込みました。',
            downloading: 'Downloading threat model',
            saved: '脅威モデルを書き込みました。'
        },
        properties: {
            title: 'プロパティー',
            emptyState: '図面から要素を選択してください',
            name: '名前',
            text: 'テキスト',
            description: '概要',
            outOfScope: '対象外',
            bidirection: '双方向',
            reasonOutOfScope: '対象外となる理由',
            handlesCardPayment: '決済情報を扱っている',
            handlesGoodsOrServices: '商品やサービスを扱っている',
            isALog: 'ログ',
            isEncrypted: '暗号化されている',
            isSigned: '署名されている',
            isWebApplication: 'ウェブアプリ',
            privilegeLevel: '権限レベル',
            providesAuthentication: '認証を行っている',
            protocol: 'プロトコル',
            publicNetwork: '公衆ネットワーク',
            storesCredentials: '認証情報を保管している',
            storesInventory: '登録簿を保管している'
        },
        buttons: {
            delete: '選択を削除',
            redo: '繰り返す',
            shortcuts: 'キーボードショートカット',
            toggleGrid: 'グリッドの表示',
            undo: '戻す',
            zoomIn: '拡大',
            zoomOut: '縮小'
        },
        shortcuts: {
            title: 'キーボードショートカット',
            copy: {
                shortcut: '(コントロール/コマンド) + c',
                action: 'コピー'
            },
            paste: {
                shortcut: '(コントロール/コマンド) + v',
                action: '貼り付ける'
            },
            undo: {
                shortcut: '(コントロール/コマンド) + z',
                action: '戻す'
            },
            redo: {
                shortcut: '(コントロール/コマンド) + y',
                action: '繰り返す'
            },
            delete: {
                shortcut: '削除',
                action: '削除'
            },
            pan: {
                shortcut: 'シフト + 左クリック (ドラッグとドロップ)',
                action: '移動する'
            },
            multiSelect: {
                shortcut: '空白に左クリックとドラッグ',
                action: '複数の要素を選択'
            },
            zoom: {
                shortcut: '(コントロール/コマンド) + ホイール',
                action: '拡大・縮小'
            },
            save: {
                shortcut: '(ctrl/cmd) + s',
                action: 'Save'
            }
        },
        stencil: {
            boundaries: '境界',
            components: 'コンポーネント',
            entities: 'エンティティ',
            metadata: 'メタデータ',
            search: '検索',
            notFound: '見付かりませんでした。チケットを切りますか？ :)'
        },
        shapes: {
            actor: 'アクター',
            flow: 'データフロー',
            flowStencil: 'データフロー',
            process: 'プロセス',
            store: 'データストア',
            text: '説明',
            trustBoundary: '信頼境界線'
        }
    },
    forms: {
        apply: '適用',
        cancel: '取り消し',
        close: '閉じる',
        closeModel: 'モデルを閉じる',
        delete: '削除',
        discardTitle: '変更を破棄',
        discardMessage: '変更を本当に破棄しますか？',
        duplicate: ' 複製する',
        edit: '編集',
        export: 'エクスポート',
        exportAs: '次としてエキスポート',
        exportHtml: 'HTMLとして保存',
        exportPdf: 'PDFとして保存',
        exportTd: 'オリジナル(Threat Dragon)',
        exportTemplate: 'As Template',
        exportTmBom: 'As TM-BOM',
        exportOtm: '脅威モデル(OTM)を開く',
        import: 'インポート',
        ok: 'OK',
        open: '開く',
        openModel: 'モデルを開く',
        print: '印刷',
        reload: '再読み込み',
        remove: '削除',
        report: 'レポート',
        save: '保存',
        saveAs: '名前を付けて保存',
        saveModel: 'モデルを保存',
        saveModelAs: '名前を付けてモデルを保存',
        search: '検索',
        next: '次',
        previous: '前の'
    },
    cards: {
        details: 'カードの詳細',
        noDetails: '詳細はありません',
        unknown: '不明',
        properties: {
            suit: 'カテゴリ',
            number: '番号'
        },
    },
    threats: {
        model: {
            cia: {
                header: '--- CIA ---',
                confidentiality: '機密性',
                integrity: '完全性',
                availability: '可用性'
            },
            ciadie: { // Source: https://www.fastly.com/jp/blog/the-dept-of-know-live-sounil-yu-on-why-embracing-the-die-security-model-means-faster-innovation
                header: '--- CIA-DIE ---',
                confidentiality: '機密性',
                integrity: '完全性',
                availability: '可用性',
                distributed: '分散化',
                immutable: '不変',
                ephemeral: '一時的'
            },
            linddun: { // No Japanese sources for LINDDUN; using English terms
                header: '--- LINDDUN ---',
                linkability: 'Linkability',
                identifiability: 'Identifiability',
                nonRepudiation: 'Non-repudiation',
                detectability: 'Detectability',
                disclosureOfInformation: 'Disclosure Of Information',
                unawareness: 'Unawareness',
                nonCompliance: 'Non-compliance'
            },
            plot4ai: { // No Japanese sources for PLOT4ai; using English terms
                header: '--- PLOT4ai ---',
                techniqueProcesses: 'Technique & Processes',
                accessibility: 'Accessibility',
                identifiabilityLinkability: 'Identifiability & Linkability',
                security: 'Security',
                safety: 'Safety',
                unawareness: 'Unawareness',
                ethicsHumanRights: 'Ethics & Human Rights',
                nonCompliance: 'Non-Compliance'
            },
            stride: { // Source: https://learn.microsoft.com/ja-jp/azure/security/develop/threat-modeling-tool-threats
                header: '--- STRIDE ---',
                spoofing: 'なりすまし',
                tampering: '改竄',
                repudiation: '否認',
                informationDisclosure: '情報漏洩',
                denialOfService: 'サービス拒否',
                elevationOfPrivilege: '特権の昇格'
            },
            eop: {
                header: '--- EoP ---',
                dataValidationAndEncoding: 'Data Validation & Encoding', 
                authentication: 'Authentication', 
                sessionManagement: 'Session Management', 
                authorization: 'Authorization', 
                cryptography: 'Cryptography', 
                cornucopia: 'Cornucopia',
                wildCard: 'Wild Card'
            }
        },
        generic: {
            default: '脅威を追加',
            cia: 'CIA脅威を追加',
            ciadie: 'CIA-DIE脅威を追加',
            linddun: 'LINDDUN脅威を追加',
            plot4ai: 'PLOT4ai脅威を追加',
            stride: 'STRIDE脅威を追加',
            eop: 'EoPゲーム脅威を追加',
        },
        edit: '脅威を編集',
        confirmDeleteTitle: '削除の確認',
        confirmDeleteMessage: '本当に脅威を削除しますか',
        description: '脅威の詳細を追記してください',
        emptyThreat: '図面から要素を選んで脅威を追加してください',
        mitigation: '脅威の解決策を指定するか、ステータスがN/Aの場合に理由を指定してください',
        newThreat: '脅威を追加',
        newThreatByType: '種別から脅威を追加',
        newThreatByContext: 'コンテキストから脅威を追加',
        properties: {
            description: '概要',
            mitigation: '解決策',
            modelType: 'モデル型',
            number: '番号',
            severity: '優先度',
            score: '結果',
            status: 'ステータス',
            title: 'タイトル',
            type: '種別'
        },
        status: {
            notApplicable: 'N/A',
            open: '未対応',
            mitigated: '解決済み'
        },
        severity: {
            tbd: '未定',
            low: '低',
            medium: '中',
            high: '高',
            critical: '致命的'
        },
        validation: {
            error: 'カード番号は必須です。',
            cardNumberRequired: '保存する前にカード番号を選択する必要があります。'
        }
    },
    report: {
        options: {
            showOutOfScope: '対象外の要素を表示',
            showMitigatedThreats: '解決済みの脅威を表示',
            showModelDiagrams: 'モデルの図面を表示',
            showEmpty: '空要素を表示',
            showProperties: 'Show element properties',
            showBranding: 'Threat Dragonロゴ'
        },
        title: '脅威レポート',
        dateGenerated: '作成日付',
        executiveSummary: 'あらすじ',
        notProvided: '未指定',
        summary: '集計表',
        threatStats: {
            total: '脅威総数',
            mitigated: '対策済みの脅威',
            notApplicable: 'Total Not Applicable',
            notMitigated: '未対策の脅威',
            openCritical: '未対応 / 最優先事項',
            openHigh: '未対応 / 高優先度',
            openMedium: '未対応 / 中優先度',
            openLow: '未対応 / 低優先度',
            openTbd: '未対応 / 優先度は未定',
            openUnknown: '未対応 / 優先度不明'
        }
    },
    upgrade: {
        modal: {
            header: '脅威モデルを更新',
            welcome: 'OWASP Threat Dragonバージョン2へようこそ！',
            p1: 'バージョン2が使用している表示ライブラリが変わったため、脅威モデルのデータフォーマットに変更がありました。表示には以前と変わりがないが、場合によって図面を修正する必要があります。',
            p2: 'モデルを閉じると、バージョン2のフォーマットでの表示が映ります。図面を修正する必要があるか確認してください。一旦保存したら再び修正する必要がないので、このメッセージは今後表示されません。'
        },
        instructions: '素晴らしい！モデルに進みましょう。',
        continue: '脅威モデルへ進む'
    }
};

export default messages;
