const messages = {
    auth: {
        sessionExpired: 'Your session has expired. Please log in again to continue.'
    },
    nav: {
        loggedInAs: 'Logged in as',
        logOut: 'Log out',
        contentManagement: 'Content Management'
    },
    home: {
        title: 'OWASP Threat Dragon',
        imgAlt: 'Threat Dragon Logo',
        description: 'OWASP Threat Dragon is a free, open-source, cross-platform application for creating threat models. Use it to draw threat modeling diagrams and to identify threats for your system. With an emphasis on flexibility and simplicity it is easily accessible for all types of users.'
    },
    providers: {
        desktop: {
            displayName: 'Threat Dragon',
            loginWith: 'Start'
        },
        github: {
            displayName: 'GitHub',
            loginWith: 'Login with'
        },
        gitlab: {
            displayName: 'GitLab',
            loginWith: 'Login with'
        },
        bitbucket: {
            displayName: 'Bitbucket',
            loginWith: 'Login with'
        },
        google: {
            displayName: 'Google',
            loginWith: 'Login with'
        },
        local: {
            displayName: 'Local Session',
            loginWith: 'Login to'
        }
    },
    dashboard: {
        welcome: {
            title: 'Welcome!',
            description: 'You\'re ready to start making your application designs more secure. You can open an existing threat model or create a new one by choosing one of the options below. '
        },
        actions: {
            openExisting: 'Open an existing threat model',
            createNew: 'Create a new, empty threat model',
            readDemo: 'Explore a sample threat model',
            importExisting: 'Import a threat model via JSON',
            createFromTemplate: 'Create model from a Template'
        }
    },
    demo: {
        select: 'Select a demo threat model from the list below'
    },
    desktop: {
        file: {
            heading: 'File',
            clearRecentDocs: 'Clear Menu',
            close: 'Close Model',
            closeWindow: 'Close Window',
            new: 'New Model',
            open: 'Open Model',
            recentDocs: 'Open Recent',
            save: 'Save Model',
            saveAs: 'Save Model As'
        },
        help: {
            heading: 'Help',
            docs: 'Documentation',
            visit: 'Visit us at OWASP',
            sheets: 'OWASP Cheat Sheets',
            github: 'Visit us on GitHub',
            submit: 'Submit an Issue',
            check: 'Check for updates ...',
            about: {
                about: 'About',
                version: 'Version'
            }
        }
    },
    repository: {
        select: 'Select a',
        from: 'repository from the list below',
        noneFound: 'No repositories found. To get started, create a new repository on'
    },
    branch: {
        select: 'Select a branch from',
        from: 'from the list below or',
        chooseRepo: 'choose another repo',
        or: 'or',
        addNew: 'add a new branch',
        protectedBranch: 'Protected branch',
        nameRequired: 'Branch name is required',
        nameExists: 'Branch name already exists',
        refBranch: 'Reference branch',
        add: 'add branch',
        cancel: 'Cancel',
        name: 'branch name',
    },
    folder: {
        select: 'Select a',
        from: 'folder from the list below',
        noneFound: 'This folder is empty, You can create a new threat model here.'
    },
    threatmodelSelect: {
        select: 'Select a Threat Model from',
        from: 'from the list below, or choose another',
        branch: 'branch',
        or: 'or',
        repo: 'repo',
        newThreatModel: 'Create a New Threat Model'
    },
    template:{
        startFromLocalTemplate: 'Start from a Local Template',
        select: 'Select a Template from the list below',
        selectDescription: 'Templates provide a starting point for new threat models, pre-populated with relevant components and threats.',
        noTemplates: 'No templates found',
        templatesLocalSession: 'Remote templates are not available for local sessions.',
        search: 'Search templates...',
        exportTemplate: 'Export as Template',
        tags: 'Tags',
        name: 'Template Name',
        description: 'Template Description',
        saveTemplate: 'Save Template',
        addNew: 'Add New Template',
        manage: 'Manage Templates',
        manageDescription: 'Import, export, and manage your threat model templates here.',
        editTemplate: 'Edit Template',
        addTagsPlaceholder: 'Add tags...',
        updateSuccess: 'Template updated successfully',
        importSuccess: 'Template imported successfully',
        deleteSuccess: 'Template deleted successfully',
        deleteTitle: 'Confirm Delete',
        deleteConfirm: 'Are you sure you want to delete "{name}"?',
        errors: {
            invalidJson: 'Invalid JSON. Please check your template file and try again',
            invalidTemplate: 'Invalid template format. Please check your template file and try again',
            loadFailed: 'Failed to load templates. Please try again',
            duplicateTemplate: 'A template with this name already exists. Please use a different name',
            updateFailed: 'Failed to update template',
            deleteFailed: 'Failed to delete template'
        },
        warnings: {
            templateSave: 'Could not save the template. Check the developer console for more information',
            invalidSchema: 'Template does not strictly match schema. Details in the developer console'
        },
        prompts: {
            templateSaved: 'Template successfully saved',
            templateDownloading: 'Downloading template'
        },
        repo: {
            notInitialized: {
                title: 'Template Repository Not Initialized',
                userMessage: 'The template repository has not been initialized. Please contact your administrator.',
                adminMessage: 'Please go to the Manage Templates page to initialize the template repository.'
            },
            notConfigured: {
                title: 'Template Repository Not Configured',
                userMessage: 'The template repository is not configured. Please set up the repository to access templates.'
            },
            notFound: {
                title: 'Template Repository Not Found',
                userMessage: 'The repository {repoName} is not a valid repository. Please check your configuration.'
            },
            bootstrap:{
                bootstrapping:'Initializing..',
                title: 'Initialize Template Repository',
                description: 'This will create the necessary folder structure within the repository if it does not already exist.',
                action: 'Initialize',
                success: 'Template repository successfully initialized.',
                error: 'Could not initialize the template repository. Check the developer console for more information.'
            }
        },
    },
    threatmodel: {
        contributors: 'Contributors',
        contributorsPlaceholder: 'Start typing to add a contributor',
        description: 'High level system description',
        dragAndDrop: 'Drag and drop or ',
        editing: 'Editing',
        jsonPaste: 'Drop a threat model JSON file or paste its content here:',
        owner: 'Owner',
        reviewer: 'Reviewer',
        title: 'Title',
        diagram: {
            diagrams: 'Diagrams',
            addNewDiagram: 'Add a new diagram...',
            generic: {
                defaultTitle: 'New generic diagram',
                defaultDescription: 'New generic diagram description',
                select: 'Generic'
            },
            stride: {
                defaultTitle: 'New STRIDE diagram',
                defaultDescription: 'New STRIDE diagram description',
                select: 'STRIDE'
            },
            linddun: {
                defaultTitle: 'New LINDDUN diagram',
                defaultDescription: 'New LINDDUN diagram description',
                select: 'LINDDUN'
            },
            plot4ai: {
                defaultTitle: 'New PLOT4ai diagram',
                defaultDescription: 'New PLOT4ai diagram description',
                select: 'PLOT4ai'
            },
            die: {
                defaultTitle: 'New CIA-DIE diagram',
                defaultDescription: 'New CIA-DIE diagram description',
                select: 'CIADIE'
            },
            cia: {
                defaultTitle: 'New CIA diagram',
                defaultDescription: 'New CIA diagram description',
                select: 'CIA'
            },
            eop: {
                defaultTitle: 'New EoP diagram',
                defaultDescription: 'New EoP diagram description',
                select: 'EoP'
            }
        },
        threats: 'Threats',
        errors: {
            create: 'Could not create the threat model file.  Check the developer console for more information',
            dropSingleFileOnly: 'Drag and drop requires a single file.',
            invalidJson: 'Invalid JSON. Please check your model and try again',
            invalidModel: 'The threat model file does not validate correctly. Please check your model and try again',
            onlyJsonAllowed: 'Only files that end with .json are supported.',
            open: 'Error opening this Threat Model. Check the developer console for more information',
            save: 'Error saving the Threat Model. Check the developer console for more information',
            createConflict: 'A threat model with this name already exists. Please use a different name.'
        },
        warnings: {
            export: 'Could not export the Threat Model. Check the developer console for more information',
            jsonSchema: 'Model does not strictly match schema. Details from the developer console',
            noModelOpen: 'No model open',
            otmUnsupported: 'Import of Open Threat Model file format not yet supported',
            save: 'Could not save the Threat Model. Check the developer console for more information',
            tmUnsupported: 'Import of TM-BOM files converts the file format to Threat Dragon',
            v1Translate: 'Imported version 1.x model has been upgraded to the version 2.x format'
        },
        prompts: {
            created: 'Threat model successfully created',
            exported: 'Threat model exported',
            opened: 'Threat model successfully opened',
            downloading: 'Downloading threat model',
            saved: 'Threat model successfully saved'
        },
        properties: {
            title: 'Properties',
            emptyState: 'Select an element on the graph to edit',
            name: 'Name',
            text: 'Text',
            description: 'Description',
            outOfScope: 'Out of Scope',
            bidirection: 'Bidirectional',
            reasonOutOfScope: 'Reason for out of scope',
            handlesCardPayment: 'Card payment',
            handlesGoodsOrServices: 'Goods or Services',
            isALog: 'Is a Log',
            isEncrypted: 'Encrypted',
            isSigned: 'Signed',
            isWebApplication: 'Web Application',
            privilegeLevel: 'Privilege Level',
            providesAuthentication: 'Provides Authentication',
            protocol: 'Protocol',
            publicNetwork: 'Public Network',
            storesCredentials: 'Stores Credentials',
            storesInventory: 'Stores Inventory'
        },
        buttons: {
            delete: 'Delete selected',
            redo: 'Redo edit',
            shortcuts: 'Keyboard shortcuts',
            toggleGrid: 'Toggle grid',
            undo: 'Undo edit',
            zoomIn: 'Zoom in',
            zoomOut: 'Zoom out'
        },
        shortcuts: {
            title: 'Shortcuts',
            copy: {
                shortcut: '(ctrl/cmd) + c',
                action: 'Copy'
            },
            paste: {
                shortcut: '(ctrl/cmd) + v',
                action: 'Paste'
            },
            undo: {
                shortcut: '(ctrl/cmd) + z',
                action: 'Undo'
            },
            redo: {
                shortcut: '(ctrl/cmd) + y',
                action: 'Redo'
            },
            delete: {
                shortcut: 'del',
                action: 'Delete'
            },
            pan: {
                shortcut: 'shift + left-click (hold/drag)',
                action: 'Pan'
            },
            multiSelect: {
                shortcut: 'left-click on empty space and drag',
                action: 'Multi-select'
            },
            zoom: {
                shortcut: '(ctrl/cmd) + mousewheel',
                action: 'Zoom'
            },
            save: {
                shortcut: '(ctrl/cmd) + s',
                action: 'Save'
            }
        },
        stencil: {
            boundaries: 'Boundaries',
            components: 'Components',
            entities: 'Entities',
            metadata: 'Metadata',
            search: 'Search',
            notFound: 'We don\'t have that yet, want to open an issue? :)'
        },
        shapes: {
            actor: 'Actor',
            flow: 'Data Flow',
            flowStencil: 'Data Flow',
            process: 'Process',
            store: 'Store',
            text: 'Descriptive text',
            trustBoundary: 'Trust Boundary'
        }
    },
    forms: {
        apply: 'Apply',
        cancel: 'Cancel',
        close: 'Close',
        closeModel: 'Close Model',
        delete: 'Delete',
        discardTitle: 'Discard Changes?',
        discardMessage: 'Are you sure you want to discard your changes?',
        duplicate: 'Дублювати',
        edit: 'Edit',
        export: 'Експортувати',
        exportAs: 'Export Model As',
        exportHtml: 'HTML Report',
        exportPdf: 'PDF Report',
        exportTd: 'Original (Threat Dragon)',
        exportTemplate: 'As Template',
        exportTmBom: 'As TM-BOM',
        exportOtm: 'Open Threat Model (OTM)',
        import: 'Import',
        ok: 'OK',
        open: 'Open',
        openModel: 'Open Model',
        print: 'Print',
        reload: 'Reload',
        remove: 'Remove',
        report: 'Report',
        save: 'Save',
        saveAs: 'Save As',
        saveModel: 'Save Model',
        saveModelAs: 'Save Model As',
        search: 'Search',
        next:'Next',
        previous:'Previous'
    },
    cards: {
        details: 'Деталі картки',
        noDetails: 'деталі недоступні',
        unknown: 'Невідомо',
        properties: {
            suit: 'Category',
            number: 'Number'
        },
    },
    threats: {
        model: {
            cia: {
                header: '--- CIA ---',
                confidentiality: 'Confidentiality',
                integrity: 'Integrity',
                availability: 'Availability'
            },
            ciadie: {
                header: '--- CIA-DIE ---',
                confidentiality: 'Confidentiality',
                integrity: 'Integrity',
                availability: 'Availability',
                distributed: 'Distributed',
                immutable: 'Immutable',
                ephemeral: 'Ephemeral'
            },
            linddun: {
                header: '--- LINDDUN ---',
                linkability: 'Linkability',
                identifiability: 'Identifiability',
                nonRepudiation: 'Non-repudiation',
                detectability: 'Detectability',
                disclosureOfInformation: 'Disclosure of information',
                unawareness: 'Unawareness',
                nonCompliance: 'Non-compliance'
            },
            plot4ai: {
                header: '--- PLOT4ai ---',
                techniqueProcesses: 'Technique & Processes',
                accessibility: 'Accessibility',
                identifiabilityLinkability: 'Identifiability & Linkability',
                security: 'Security',
                safety: 'Safety',
                unawareness: 'Unawareness',
                ethicsHumanRights: 'Ethics & Human Rights',
                nonCompliance: 'Non-compliance'
            },
            stride: {
                header: '--- STRIDE ---',
                spoofing: 'Spoofing',
                tampering: 'Tampering',
                repudiation: 'Repudiation',
                informationDisclosure: 'Information disclosure',
                denialOfService: 'Denial of service',
                elevationOfPrivilege: 'Elevation of privilege'
            },
            eop: {
                header: '--- EoP ---',
                dataValidationAndEncoding: 'Data Validation & Encoding', 
                authentication: 'Authentication', 
                sessionManagement: 'Session Management', 
                authorization: 'Authorization', 
                cryptography: 'Cryptography', 
                cornucopia: 'Cornucopia',
                wildCard: 'Wild Card'
            }
        },
        generic: {
            default: 'New generic threat',
            cia: 'New CIA threat',
            ciadie: 'New CIA-DIE threat',
            linddun: 'New LINDDUN threat',
            plot4ai: 'New PLOT4ai threat',
            stride: 'New STRIDE threat',
            eop: 'New EoP threat'
        },
        edit: 'Edit Threat',
        confirmDeleteTitle: 'Confirm Delete',
        confirmDeleteMessage: 'Are you sure you really want to delete this threat?',
        description: 'Provide a description for this threat',
        emptyThreat: 'Select an element on the graph to add a threat',
        mitigation: 'Provide remediation for this threat or a reason if status is N/A',
        newThreat: 'New Threat',
        newThreatByType: 'New Threat by Type',
        newThreatByContext: 'New Threat by Context',
        properties: {
            description: 'Description',
            mitigation: 'Mitigations',
            modelType: 'Model Type',
            number: 'Number',
            severity: 'Severity',
            score: 'Score',
            status: 'Status',
            title: 'Title',
            type: 'Type'
        },
        status: {
            notApplicable: 'N/A',
            open: 'Open',
            mitigated: 'Mitigated'
        },
        severity: {
            tbd: 'TBD',
            low: 'Low',
            medium: 'Medium',
            high: 'High',
            critical: 'Critical'
        },
        validation: {
            error: 'Card number is required',
            cardNumberRequired: 'You must select a card number before saving.'
        }
    },
    report: {
        options: {
            showOutOfScope: 'Show out of scope elements',
            showMitigatedThreats: 'Show mitigated threats',
            showModelDiagrams: 'Show model diagrams',
            showEmpty: 'Show empty elements',
            showProperties: 'Show element properties',
            showBranding: 'Threat Dragon logo'
        },
        title: 'Threat model report for',
        dateGenerated: 'Date Generated',
        executiveSummary: 'Executive Summary',
        notProvided: 'Not provided',
        summary: 'Summary',
        threatStats: {
            total: 'Total Threats',
            mitigated: 'Total Mitigated',
            notApplicable: 'Total Not Applicable',
            notMitigated: 'Total Open',
            openCritical: 'Open / Critical Severity',
            openHigh: 'Open / High Severity',
            openMedium: 'Open / Medium Severity',
            openLow: 'Open / Low Severity',
            openTbd: 'Open / TBD Severity',
            openUnknown: 'Open / Unknown Severity'
        }
    },
    upgrade: {
        modal: {
            header: 'Threatmodel Update',
            welcome: 'Welcome to version 2 of OWASP Threat Dragon!',
            p1: 'Version 2 uses a different drawing library, which will change the way parts of your threat models are saved. While most diagrams will look the same as they did in previous versions of Threat Dragon, there are cases where they may need to be adjusted slightly.',
            p2: 'After closing this modal, you will see how each diagram in this model renders in the version 2 format. Please make note of any diagrams you may need to adjust. This is a one-time upgrade, and you should not see this message again after saving this model.'
        },
        instructions: 'Great! Let\'s get you to your model.',
        continue: 'Continue to Threat Model'
    }
};

export default messages;
