{{ .ACLConfig }}

{{ .TLSConfig }}

{{ .GRPCConfig }}

{{ .EDAConfig }}

{{- if .EnableGNMIUnixSockServices }}
system gnmi-server unix-socket services [ gnmi gnoi ] admin-state enable
{{- end }}

{{ .DNSServersConfig }}

set / system json-rpc-server admin-state enable network-instance mgmt http admin-state enable
set / system json-rpc-server admin-state enable network-instance mgmt https admin-state enable tls-profile clab-profile

{{ .SNMPConfig }}

{{ .NetconfConfig }}

{{ .OCServerConfig }}

{{ .NDKServerConfig }}

set / system lldp admin-state enable
set / system aaa authentication idle-timeout 7200

{{- /* if e.g. node is run with none mgmt networking but a macvlan interface is attached as mgmt0, we need to adjust the mtu */}}
{{- if ne .MgmtMTU 0 }}
set / interface mgmt0 mtu {{ .MgmtMTU }}
{{- end }}

{{- if ne .MgmtIPMTU 0 }}
set / interface mgmt0 subinterface 0 ip-mtu {{ .MgmtIPMTU }}
{{- end }}

{{- /* enabling interfaces referenced as endpoints for a node (both e1-2 and e1-3-1 notations) */}}
{{- range $epName, $ep := .IFaces }}
set / interface {{ $ep.BaseName }} admin-state enable
  {{- if ne $ep.Mtu 0 }}
set / interface {{ $ep.BaseName }} mtu {{ $ep.Mtu }}
  {{- end }}

  {{- if $ep.HasBreakout }}
set / interface {{ $ep.BaseName }} breakout-mode num-breakout-ports 4 breakout-port-speed 25G
set / interface {{ $ep.FullName }} admin-state enable
  {{- end }}

  {{- /* If per-endpoint IPv4/IPv6 are provided, configure them on subinterface 0 */}}
  {{- if or $ep.IPv4 $ep.IPv6 }}
set / interface {{ $ep.FullName }} subinterface 0 admin-state enable
    {{- if $ep.IPv4 }}
set / interface {{ $ep.FullName }} subinterface 0 ipv4 address {{ $ep.IPv4 }}
set / interface {{ $ep.FullName }} subinterface 0 ipv4 admin-state enable
    {{- end }}
    {{- if $ep.IPv6 }}
set / interface {{ $ep.FullName }} subinterface 0 ipv6 address {{ $ep.IPv6 }}
set / interface {{ $ep.FullName }} subinterface 0 ipv6 admin-state enable
    {{- end }}
  {{- end }}
{{ end -}}
{{- if .SSHPubKeys }}
set / system aaa authentication linuxadmin-user ssh-key [ {{ .SSHPubKeys }} ]
set / system aaa authentication admin-user ssh-key [ {{ .SSHPubKeys }} ]
{{- end }}
set / system banner login-banner "{{ .Banner }}"

{{- if .EnableCustomPrompt }}
environment save file /home/admin/srlinux_orig.rc
{{- if ne .CustomPrompt  "" }}
environment prompt "{{ .CustomPrompt }}"
environment save file /home/admin/.srlinuxrc
{{- end }}
{{- end }}
